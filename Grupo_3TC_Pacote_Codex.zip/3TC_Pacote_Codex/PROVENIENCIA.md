# Proveniência e decisões de escopo

## Base de conteúdo
Histórico visível desta conversa, especialmente:
- correção do posicionamento: indústria como atividade principal; software, educação e engenharia apoiam produtos;
- tese “O calor custa caro” e frases de abertura/fechamento selecionadas;
- exclusão do gráfico de barras na apresentação;
- cenário final de 100 trabalhadores, R$ 4 mil, 3%, R$ 10 mil/mês, 3% a.a., R$ 10 milhões e 1%;
- pedido de total anual e de cinco anos e de fontes abaixo das premissas;
- interesse em retorno operacional e margem, com retirada do exemplo financeiro do slide de benefícios;
- pedidos de bibliografia com downloads, documento Word e compilação PDF.

O resumo “Grupo_3TC_Compilacao_Parcial_Conversa.pdf”, páginas 1–3, foi lido apenas como apoio. Ele próprio declara ser parcial. As últimas correções explícitas do usuário prevalecem sobre versões anteriores e sobre esse resumo. Não foram reconstituídos trechos editados ou eliminados como se ainda fossem conteúdo aprovado.

## Cálculo independente
Feito com Decimal:
- ano 1: R$ 247.600,00;
- energia incremental em cinco anos: R$ 56.209,186116 antes do arredondamento;
- exposição total em cinco anos: R$ 1.276.209,186116;
- apresentação monetária: R$ 1.276.209,19.
Esse cálculo confirma operações matemáticas, não a representatividade das hipóteses.

## Proposta funcional acrescentada
Interface web, motor reutilizável, persistência local, comparação de cenários, exportadores, módulo separado de ROI, biblioteca estruturada e automação de testes são uma tradução proposta das necessidades. O chat não especificou todos os seus detalhes técnicos.

## Limites
Não se confirmou desempenho de produtos 3TC, origem de todas as estatísticas, liderança setorial, disponibilidade de APIs, orçamento ou retorno garantido. A aplicação deve manter essas distinções.

Não se adotaram como fatos financeiros da 3TC as projeções de receita, EBITDA ou venda da empresa mencionadas em respostas anteriores do assistente. Elas não são necessárias para a calculadora e não devem contaminar a implementação.

## Documentação oficial consultada para a orientação de execução
- Custom instructions with AGENTS.md:
  https://developers.openai.com/codex/guides/agents-md
- Iterating Development Workflows with Codex:
  https://developers.openai.com/cookbook/examples/codex/iterating-development-workflows-with-codex
- Codex Prompting Guide:
  https://developers.openai.com/cookbook/examples/gpt-5/codex_prompting_guide

Essas referências orientam instruções persistentes, execução e evidência de testes. Não são fontes para o modelo econômico ou para as alegações científicas.
