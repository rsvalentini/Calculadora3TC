# PROMPT MESTRE — GRUPO 3TC | O CALOR CUSTA CARO
## Implementação com Codex: calculadora, apresentação, análise de investimento e biblioteca de evidências

### 0. Missão e forma de execução

Atue como agente líder de engenharia de software, responsável por transformar este briefing em software funcional, testado e documentado. Utilize efetivamente o Codex disponível no ambiente para inspecionar o repositório, implementar, executar testes, revisar e corrigir. Se você já estiver executando no Codex, realize essas atividades diretamente. Não pare na proposta de arquitetura, em telas estáticas ou em uma lista de tarefas.

Antes de editar, identifique o repositório, suas instruções AGENTS.md, a stack existente, os testes e as alterações não commitadas. Preserve o trabalho existente. Escolhas técnicas reversíveis podem ser tomadas e registradas sem pedir aprovação a cada detalhe. Mudanças destrutivas, publicação externa, push, acesso a dados reais, contratação de serviços e uso de credenciais exigem autorização específica.

Se o Codex ou outra capacidade necessária estiver indisponível, declare o bloqueio real. Não invente execução de ferramentas, testes ou deploy. Entregue o que puder comprovar, com pendências delimitadas. Se houver um agente orquestrador, ele deve revisar os arquivos e resultados produzidos pelo Codex, não apenas retransmitir sua conclusão.

Este briefing consolida decisões do chat e acrescenta uma proposta explícita de produto. Não trate funcionalidades propostas como pedidos históricos já aprovados. Use a classificação da seção 2 para manter essa rastreabilidade. Na ausência de instrução posterior, desenvolva primeiro o núcleo A e, em seguida, as extensões B aqui propostas; deixe C somente documentado.

### 1. Contexto empresarial e linguagem

O Grupo 3TC se apresenta como:

“O Grupo 3TC é uma indústria brasileira especializada no desenvolvimento e na fabricação de produtos de isolamento térmico com tecnologia própria, integrando soluções de engenharia e inovação para combater os impactos do calor.”

O núcleo econômico é desenvolver, fabricar e comercializar produtos de isolamento térmico. Engenharia de aplicação, pesquisa, educação, ações sociais e ferramentas digitais fortalecem esse negócio industrial. Não reposicione o grupo como empresa de software, consultoria generalista ou conglomerado de unidades independentes.

A ferramenta é instrumento de educação de mercado e apoio comercial. Seu objetivo é tornar os custos potenciais do calor compreensíveis e apoiar a avaliação de intervenções tecnicamente justificadas. Não constitui laudo, projeto térmico, orçamento, previsão climática local nem garantia de resultado.

Preserve estas mensagens aprovadas:
- “O calor custa caro.”
- “As altas temperaturas afetam diretamente a eficiência das empresas, gerando custos operacionais, perdas de produtividade e riscos para os negócios.”
- “O maior custo do calor pode ser aquele que seu negócio ainda não mede.”
- “Combater o calor é investir no presente e preparar o futuro.”
- “Grupo 3TC. O Inimigo nº 1 do Calor.”

A expressão “O calor custa caro” é a tese central das apresentações e título pretendido de um livro; não afirme registro ou proteção jurídica. Utilize português brasileiro, redação direta e linguagem empresarial compreensível. Evite “mais do que”, “não somos apenas” e superlativos sem prova.

Contexto das linhas: Manta Térmica — eficiência térmica e flexibilidade; Placa Térmica — eficiência térmica e praticidade; Forro Térmico Modular — eficiência térmica e estética. Serviços: aplicação e instalação dos produtos 3TC, acompanhamento de instalação por terceiros e climatização complementar por parceiros, mediante avaliação e integração com os produtos. Esses dados contextualizam a ferramenta; não autorizam recomendação automática de produto.

O histórico também menciona atuação desde 2013, mais de 4.500 clientes, 5.500 projetos e quatro edições do ranking EXAME. São informações institucionais fornecidas na conversa, não verificadas por este briefing. Não publique automaticamente exclusividade setorial, superioridade técnica, logos de clientes ou estatísticas empresariais sem documentação e autorização.

A sequência narrativa é: identidade e autoridade → problema do calor → custos → simulação → valor da eficiência térmica → especialização, tecnologia, produtos, aplicações e resultados. O software precisa servir a essa narrativa, não substituir a apresentação completa.

### 2. Escopo rastreável

**A — Núcleo explicitamente definido no chat; prioridade máxima**
A1. Simulação editável de perda de produtividade.
A2. Simulação de aumento do gasto energético de resfriamento em cinco anos.
A3. Simulação de perdas de materiais termossensíveis.
A4. Resultado do primeiro ano e acumulado em cinco anos.
A5. Fontes imediatamente abaixo das premissas de cada componente.
A6. Visão de apresentação sem gráfico de barras.
A7. Distinção explícita entre premissa hipotética, evidência e economia garantida.
A8. Análise de possibilidade de retorno operacional e contribuição à margem, sem presumir retorno universal.
A9. Organização das fontes e links, com necessidade de documentos Word/PDF já manifestada no chat.

**B — Tradução funcional proposta neste briefing; não foi especificada integralmente no chat**
B1. Aplicação web responsiva com modo de edição e modo de apresentação.
B2. Módulo separado e opcional de investimento, retorno e margem.
B3. Salvar, duplicar, comparar, importar e exportar cenários locais.
B4. Relatório PDF e DOCX da simulação, memória de cálculo CSV e cenário JSON.
B5. Biblioteca navegável de fontes, com status de verificação e exportação.
B6. Testes automatizados, documentação, empacotamento e instruções de implantação.

**C — Fora da primeira entrega**
Integração real com 3TClima; dados meteorológicos automáticos; cálculo termodinâmico da edificação; dimensionamento HVAC; CRM; cobrança; autenticação multiempresa; armazenamento em nuvem; catálogo ou cotação automáticos; chatbot; monitoramento contínuo; geração automática de todo o deck; transcrição integral do chat.

Deixe pontos de extensão documentados para C, sem criar integrações fictícias ou transformar o projeto em uma plataforma excessivamente complexa. O 3TClima foi mencionado, mas não há API, esquema de dados ou código fornecidos.

### 3. Entregue um produto integrado com quatro módulos

**Módulo 1 — Calculadora de exposição econômica ao calor**
Três componentes editáveis, resultados em tempo real após validação, detalhamento anual, hipóteses visíveis, restauração do cenário demonstrativo e exclusão de componentes não aplicáveis.

**Módulo 2 — Apresentação e relatórios**
Resumo adequado para apresentações, sem gráfico de barras, com três blocos e total anual/acumulado. Exportação de relatório com premissas, resultados, fórmulas, fontes e limitações. A biblioteca de fontes também deve poder gerar um documento próprio.

**Módulo 3 — Análise de investimento**
Ativado separadamente e somente mediante preenchimento de investimento e hipóteses de benefício. Exposição econômica não deve se converter automaticamente em economia.

**Módulo 4 — Biblioteca de evidências**
Consulta por instituição, tema e alegação; diferenciação de links para páginas, PDFs e bases de dados; status verificável; vínculo entre fonte e alegação. Não basta colocar logos de instituições como selo de validação.

Use um motor de cálculo compartilhado. Não crie quatro sistemas independentes nem duplique fórmulas entre interface, relatórios e testes.

### 4. Cenário demonstrativo final e entradas

Preserve estes valores, definidos após revisões no chat:

| Campo | Valor inicial | Interpretação |
|---|---:|---|
| Trabalhadores expostos | 100 | Número de pessoas, não toda a folha automaticamente |
| Custo mensal por trabalhador | R$ 4.000 | Custo informado, não salário líquido |
| Perda hipotética de produtividade | 3% | Hipótese ajustável |
| Gasto mensal atual com resfriamento | R$ 10.000 | Não a conta total de energia |
| Crescimento anual hipotético do consumo para resfriamento | 3% | Tarifa constante no cenário-base |
| Valor anual de materiais termossensíveis movimentados | R$ 10.000.000 | Base econômica a identificar |
| Perda anual hipotética de materiais | 1% | Perda atribuível ao calor, não perda total de todas as causas |
| Horizonte | 5 anos | Anos 1 a 5, sem confundir com anos-calendário |
| Inflação/reajuste tarifário | 0% | Fora do cenário-base |
| Crescimento da equipe e dos materiais | 0% | Constantes no cenário-base |

Exiba “Cenário demonstrativo — premissas hipotéticas” até o usuário registrar suas próprias premissas. Registrar dados próprios não os transforma em medições verificadas.

Permita editar os valores, ligar/desligar componentes e informar origem das premissas. Para materiais, adicione identificação da base: custo, preço de venda ou não informada. Não altere silenciosamente os R$ 10 milhões acordados, mas não use valor a preço de venda como custo de descarte nem como economia contábil. No módulo de ROI, o benefício de materiais exige uma base de custo explicitamente confirmada.

O custo mensal de trabalho deve explicitar a convenção de anualização por 12. Não acrescente encargos, benefícios ou provisões automaticamente, nem os conte duas vezes. Não acrescente automaticamente um fator de exposição ou uma sazonalidade ausente no cenário aprovado; tais ajustes seriam futuras extensões documentadas.

### 5. Modelo matemático obrigatório

Use taxas decimais internamente: 3% = 0,03; 1% = 0,01. Empregue aritmética decimal consistente ou representação equivalente adequada a dinheiro. Mantenha precisão durante os cálculos e arredonde apenas para exibição/exportação monetária. O cálculo deve ser determinístico e independente de modelos de linguagem.

Defina:
N = trabalhadores;
C = custo mensal por trabalhador;
p = taxa de perda de produtividade;
E = gasto mensal atual com resfriamento;
g = crescimento anual hipotético do consumo;
V = valor anual movimentado em materiais;
m = perda atribuível ao calor;
H = número inteiro de anos.

**Produtividade**
P = N × C × 12 × p

No cenário-base, P é constante por ano. Rotule:
“Valor econômico equivalente à capacidade de trabalho potencialmente perdida”.
Não rotule como redução comprovada de faturamento, lucro, folha ou desembolso. A hipótese de 3% não deve ser apresentada como coeficiente universal da OMS.

**Energia**
B = 12 × E
Energia_total_t = B × (1 + g)^t
Energia_adicional_t = B × [(1 + g)^t − 1], t = 1,...,H

O ano 1 já incorpora o primeiro crescimento. A referência é o custo anual atual constante B, e não o custo do ano anterior. Some somente Energia_adicional_t no painel de exposição, não toda a conta de resfriamento.

Energia_adicional_acumulada = soma(Energia_adicional_t, t = 1,...,H)

Não derive g automaticamente da temperatura média global. Os 3% são análise de sensibilidade, não previsão da OMM/IEA para uma empresa brasileira. Não confunda crescimento de consumo com reajuste tarifário. Uma futura extensão com ambos deve mostrá-los separadamente e conservar a comparação entre cenários equivalentes.

**Materiais**
M = V × m

M é constante por ano no cenário-base. O percentual de 1% é hipótese, não taxa publicada pela OMS. Não trate exposição fora de faixa térmica como descarte automático: a necessidade de descarte depende da avaliação aplicável, fora do escopo desta calculadora.

**Total**
Total_t = P + Energia_adicional_t + M
Total_acumulado_H = H × P + Energia_adicional_acumulada + H × M

Nome: “Exposição econômica potencial estimada”.
O total combina um equivalente de capacidade laboral, gasto energético adicional e perdas de materiais. Deve trazer ressalva de heterogeneidade, evitar sobreposição e nunca ser apresentado como prejuízo contábil comprovado.

### 6. Valores obrigatórios de conferência

| Componente | Ano 1 | Cinco anos |
|---|---:|---:|
| Produtividade | R$ 144.000,00 | R$ 720.000,00 |
| Energia adicional | R$ 3.600,00 | R$ 56.209,19 |
| Materiais | R$ 100.000,00 | R$ 500.000,00 |
| Total potencial | R$ 247.600,00 | R$ 1.276.209,19 |

Energia adicional por ano: 3.600,00; 7.308,00; 11.127,24; 15.061,06; 19.112,89.
Total potencial por ano: 247.600,00; 251.308,00; 255.127,24; 259.061,06; 263.112,89.

O histórico arredondou o acumulado para R$ 1.276.209. A precisão calculada antes do arredondamento é 1.276.209,186116. O arquivo de fixture fornecido registra essa precisão.

Inclua testes de regressão para todos esses resultados. Não ajuste fórmulas para reproduzir valores anteriores substituídos pelo usuário, como cenários com 200 trabalhadores ou R$ 30 mil mensais de energia.

### 7. Interface e apresentação

No modo de edição, use campos numéricos acessíveis, unidades explícitas e percentuais identificados. Sliders são opcionais e nunca substituem entrada direta. Trate vírgula decimal e separadores de milhar em pt-BR sem adivinhar entradas ambíguas.

No modo de apresentação, preserve esta composição:
Título: “Quanto o calor pode custar para uma empresa?”
Subtítulo: “Simulação ilustrativa dos impactos do calor sobre a produtividade, o consumo de energia e a conservação de materiais termossensíveis.”

Bloco 1: “Perda de produtividade”
Linha: “100 trabalhadores · custo mensal de R$ 4 mil · perda hipotética de 3%”.
Logo abaixo: referência, status e ressalva de aplicabilidade.
Destaque: R$ 144 mil por ano.

Bloco 2: “Aumento do custo de energia”
Linha: “R$ 10 mil/mês em resfriamento · aumento hipotético de 3% ao ano”.
Logo abaixo: referência, status e ressalva.
Destaque: R$ 3,6 mil adicionais no primeiro ano.

Bloco 3: “Perdas de materiais termossensíveis”
Linha: “R$ 10 milhões/ano movimentados · perda hipotética de 1%”.
Logo abaixo: referência, status e ressalva.
Destaque: R$ 100 mil por ano.

Final: total do primeiro ano e potencial acumulado em cinco anos, com maior destaque para o acumulado. A tela deve atualizar todos os rótulos conforme a edição, sem números fixos.

Rodapé obrigatório:
“Cenário hipotético. Não representa prejuízo contábil comprovado nem economia garantida com isolamento térmico. Produtividade é um equivalente de capacidade laboral; energia considera apenas o aumento sobre a base atual, com tarifa constante; materiais dependem da premissa informada.”

Não use gráfico de barras na visão principal nem no relatório-resumo. A preferência do usuário foi por blocos e totais. Detalhamento anual pode ser tabela expansível.

Design: industrial, sóbrio e legível; não faça parecer um software financeiro genérico. Use identidade visual real somente quando fornecida. Na ausência dela, crie tema neutro substituível, sem inventar logo oficial. Garanta navegação por teclado, foco visível, leitura por leitores de tela, contraste, layout móvel e impressão sem cortes.

### 8. Módulo opcional de investimento e retorno

O usuário pediu conexão entre eficiência térmica, retorno operacional e margem; posteriormente retirou o exemplo econômico do slide de benefícios. Portanto, mantenha este módulo fora da abertura e desligado por padrão. Não reintroduza investimento hipotético como orçamento 3TC.

Campos: investimento inicial completo I; redução estimada do gasto de resfriamento sE; custos operacionais/manutenção adicionais O_t; redução atribuível das perdas de materiais aM; recuperação de capacidade laboral aP; fator de conversão comprovável da recuperação em benefício monetário qP; receita anual R_t para margem.

I e R_t começam vazios. Benefícios não começam preenchidos com 15% ou 26%. aP, qP e aM ficam em zero até preenchimento explícito. Cada benefício deve ter natureza registrada: hipótese, estudo específico aplicável ou medição própria.

No cenário simplificado:
S_energia_t = Energia_total_t × sE
S_materiais_t = M_custo × aM
S_produtividade_t = P × aP × qP
Fluxo_incremental_t = S_energia_t + S_materiais_t + S_produtividade_t − O_t

M_custo exige base de custo confirmada; se indisponível, excluir S_materiais_t e explicar. Recuperação de produtividade não é caixa automático. qP deve representar a parcela sustentada por redução real de despesas ou margem de contribuição incremental documentada. Sem essa justificativa, mantenha o benefício apenas como capacidade recuperada, fora do fluxo.

Não duplique produção recuperada e materiais preservados se representarem o mesmo efeito. O usuário deve confirmar a separação antes de somar benefícios financeiros.

A economia de energia usa o custo total de resfriamento do cenário sem intervenção, enquanto o painel anterior mostra só o custo adicional sobre a base atual. Explique essa diferença: o ROI não é simplesmente uma porcentagem do total de exposição exibido.

Resultados:
Benefício operacional acumulado = soma(Fluxo_incremental_t)
Ganho líquido no horizonte = soma(Fluxo_incremental_t) − I
ROI simples no horizonte (%) = 100 × [soma(Fluxo_incremental_t) − I] / I
Contribuição à margem operacional (p.p.) = 100 × Fluxo_incremental_t / R_t, mantidas as demais condições.

Payback: identifique o primeiro momento em que o fluxo acumulado recupera I. Para fluxos constantes, I/fluxo anual é permitido; para fluxos variáveis, use acumulação e, se interpolar no ano de recuperação, declare a hipótese de distribuição uniforme. Se não ocorrer no horizonte, informe “Não atingido no horizonte analisado”, sem extrapolação silenciosa.

I = 0: ROI percentual não aplicável; R_t = 0/ausente: margem não calculável; fluxo negativo: apresente o resultado negativo. CAPEX não reduz automaticamente a margem operacional do primeiro ano. Não chame o ganho de lucro líquido, nem omita impostos, financiamento ou custo de capital como se já estivessem modelados. A versão básica é uma análise incremental simplificada antes desses efeitos.

Caso acrescente valor presente líquido, classifique como extensão, solicite taxa explícita e documente consistência entre fluxos nominais/reais. Não implemente métricas sofisticadas com premissas escondidas.

### 9. Fontes, evidências e limites científicos

Os links herdados do chat são candidatos bibliográficos, não atestados de verificação. Use data/fontes-candidatas.json como ponto de partida. Não preencha data de acesso, páginas, status de download ou validação sem conferir.

Prioridades temáticas:
- OMS/OMM: calor ocupacional e relação com capacidade laboral.
- IEA: temperaturas, resfriamento e demanda de energia.
- OMS: requisitos de armazenamento/transporte de produtos termossensíveis.
- OMM/PNUMA: contexto climático, não coeficiente de consumo de uma instalação.
- DOE: intervenções combinadas de isolamento e vedação em residências.
- Budaiwi, Abdou e Al-Homoud: estudo específico mencionado no chat sobre intervenções combinadas.
- OIT/Lancet Countdown: contexto de trabalho e impactos econômicos globais/regionais.

Verifique antes de publicar números como 546 mil mortes anuais, 11 anos mais quentes, 2% a 3% por grau de estresse térmico, 15% de economia residencial e até 26% de redução de resfriamento. Confira população, período, local, métrica, configuração e limitações. WBGT/IBUTG não deve ser tratado como temperatura comum do ar. Não reutilize citações inacessíveis do chat como prova.

Mesmo que um estudo seja confirmado, ele não valida automaticamente os coeficientes hipotéticos de 3%, 3% e 1%, nem demonstra desempenho da 3TC. Não some percentuais de estudos distintos. Diferencie temperatura superficial, temperatura do ar, carga térmica, consumo, custo e capacidade do equipamento.

Modelo de dados da fonte:
id, instituição, título, ano informado, tema, URL principal, URL de download confirmada ou nula, formato, alegação suportada, trecho/página quando disponível, limitações, data de acesso efetiva ou nula, status e motivo, indicadores relacionados.

Separe estados: “não verificada”, “verificada”, “acesso indisponível”, “alegação não confirmada”. Um link funcionar não confirma a alegação. Fontes não verificadas podem aparecer na biblioteca como pendentes; não podem ornamentar um card como validação científica.

Se não houver acesso externo, a calculadora continua funcionando com premissas hipotéticas e aviso de referências pendentes. Não baixe conteúdo restrito por meios indevidos nem distribua artigos protegidos sem autorização. Linkar é diferente de redistribuir arquivos.

### 10. Cenários, persistência e exportação

A primeira entrega pode funcionar inteiramente no navegador, sem servidor, login ou API paga. Proponha armazenamento local como implementação B, explique seu alcance e permita limpar dados. Não afirme segurança corporativa ou sincronização inexistentes.

Cenários devem registrar nome/identificador, parâmetros, unidades, origem das premissas, horizonte, versão do modelo, fontes relacionadas e data de geração. Dados do cliente são opcionais; não envie esses dados a serviços externos, telemetria ou modelos de linguagem.

Permita criar, duplicar, editar, excluir, comparar e restaurar cenários, com confirmação para exclusões. A comparação usa a mesma versão de modelo e explicita diferenças nas premissas. Não rotule cenários “conservador” ou “otimista” sem critérios transparentes.

JSON: exportação/importação versionada, validada, com limites de tamanho e tipos; não confie em resultados importados, recalcule-os.
CSV: memória por ano, parâmetros, unidades e convenção decimal documentada; trate células textuais para evitar fórmulas inesperadas.
PDF e DOCX: relatório executivo, parâmetros, memória, bases e limitações, sem promessas de desempenho. Links devem ser clicáveis. Não declare conformidade técnica automática.
Bibliografia: exportação Word/PDF com fontes disponíveis e pendentes claramente separadas.

Para PDF/DOCX, use recursos de renderização e revisão quando disponíveis. Verifique os arquivos gerados e a correspondência numérica com a interface. Nunca entregue apenas botões sem funcionalidade.

### 11. Arquitetura e qualidade

Se houver projeto existente, preserve sua arquitetura quando viável. Se começar do zero, proponha uma aplicação web pequena em TypeScript, com motor de cálculo puro, UI separada, validação de esquemas e testes unitários/integrados. Framework, biblioteca de exportação e gerenciador devem ser escolhidos conforme o ambiente e documentação oficial atual; registre versões e lockfile. Isso é proposta técnica, não decisão prévia do usuário.

O cálculo central não depende de IA, API climática ou internet. Codex é ferramenta de desenvolvimento, não requisito de execução do produto. Não fixe nomes de modelos ou comandos desatualizados sem verificar a interface disponível.

Separe domínio, apresentação, evidências, persistência e exportadores. Não use eval nem código derivado de arquivos importados. Não coloque segredos em frontend, repositório ou exemplo. Mantenha dados financeiros fora de logs e URLs públicas. Sem autenticação/backend, não apresente o produto como apto a guardar cadastros sensíveis compartilhados.

Faça validação de número finito, valores não negativos, pessoas/anos inteiros e percentuais de perda/recuperação entre 0 e 100. Crescimento do cenário-base é não negativo; limites de segurança numérica devem ser técnicos, explícitos e não apresentados como limites científicos. Campo vazio é diferente de zero. Não mostre resultado antigo como atualizado quando uma entrada for inválida.

### 12. Testes e critérios de aceite

Cobertura mínima:
1. Todos os valores de referência da seção 6, com precisão interna e arredondamento definidos.
2. N ou p igual a zero → produtividade zero.
3. E ou g igual a zero → energia adicional zero.
4. V ou m igual a zero → perdas de materiais zero.
5. H = 1 → acumulado igual ao total do ano 1.
6. Crescimento composto e comparação com base fixa, não com ano anterior.
7. Taxas 3% e 1% interpretadas como 0,03 e 0,01.
8. Entradas negativas, NaN, infinitas, vazias e malformadas bloqueadas.
9. Importar/exportar cenário conserva premissas, mas recalcula resultados.
10. Mesmo motor numérico em UI, modo apresentação, PDF, DOCX e CSV.
11. Fonte pendente não aparece como verificada; hipótese continua identificada.
12. ROI não usa automaticamente todo o valor de produtividade; materiais sem base adequada não entram no benefício financeiro.
13. Investimento/receita zero não produz Infinity; prejuízo permanece negativo; payback pode não ser atingido.
14. Usabilidade por teclado, estado vazio, edição, restauração, erro e layouts móvel/desktop.
15. Ausência de gráficos de barras no resumo.
16. Exportações reais abrem, não cortam conteúdo e contêm limitações e links.
17. Build, verificações estáticas e testes executados com logs.

Teste sintético exclusivo de ROI: energia anual constante de R$ 120 mil, redução hipotética de 15%, investimento de R$ 45 mil, cinco anos, sem outros benefícios/custos. Esperado: R$ 18 mil/ano, payback simples de 2,5 anos, ganho líquido de R$ 45 mil e ROI de 100%. Com receita de R$ 5 milhões/ano, contribuição teórica de 0,36 ponto percentual. Este teste não é cenário comercial padrão, cotação 3TC nem economia comprovada; o exemplo foi retirado do slide pelo usuário.

### 13. Entregáveis concretos

Entregue:
- Aplicação funcional com os módulos A e B concluídos ou com pendências claramente delimitadas.
- Código-fonte e motor de cálculo reutilizável.
- Cenário demonstrativo e fixtures numéricas.
- Biblioteca de fontes com metadados e situação real de conferência.
- Exportadores PDF, DOCX, CSV e JSON testados.
- Testes, configuração de execução, lockfile e build verificável.
- README com instalação, uso, limitações, dados locais e implantação.
- AGENTS.md conciso com invariantes e caminhos de documentos; não replique todo este prompt nele.
- MODEL.md com fórmulas, distinções financeiras e convenções.
- SOURCES.md ou equivalente com regras de uso e bibliografia.
- ACCEPTANCE.md mapeando requisitos A/B aos testes e evidências.
- TEST_REPORT.md com comandos executados, resultados, ambiente, capturas e bloqueios.
- Exemplos efetivamente gerados de relatório e cenário; dados fictícios identificados.
- Pacote ZIP ou repositório utilizável, sem segredos, caches ou dependências desnecessárias.
- Registro de decisões e backlog C, sem afirmar que C foi implementado.

Não faça deploy público nem envie a sistemas externos sem autorização. Se não puder publicar, entregue execução local reproduzível e instruções; nunca invente URL de produção.

### 14. Processo de entrega

1. Faça inspeção inicial somente de leitura e registre o escopo.
2. Confirme os valores de referência por cálculo independente.
3. Implemente e teste primeiro o domínio; depois os três componentes e seus resultados.
4. Acrescente modo apresentação, fontes e persistência.
5. Implemente o módulo de ROI como fluxo separado.
6. Implemente exportações e valide seus arquivos.
7. Execute revisão de ciência/linguagem, testes e inspeção visual.
8. Corrija problemas e empacote o resultado.

Na resposta final informe o que foi entregue, como executar, onde estão os arquivos, quais testes passaram e o que não pôde ser comprovado. Não apresente planejamento como execução. Não declare sistema pronto para produção apenas porque compilou.

**Critério de sucesso:** um integrante da equipe 3TC consegue editar premissas, compreender os três componentes, ver R$ 247.600,00 no primeiro ano e R$ 1.276.209,19 em cinco anos no cenário demonstrativo, apresentar os resultados sem gráfico de barras, abrir as fontes com seus limites, gerar relatórios consistentes e avaliar investimento sem confundir exposição econômica com economia garantida.
