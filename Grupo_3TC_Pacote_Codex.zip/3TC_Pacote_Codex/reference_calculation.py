"""Independent numerical reference. Not the application implementation."""
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
import json

def money(value: Decimal) -> str:
    return format(value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP), ".2f")

def main() -> None:
    fixture_path = Path(__file__).parent / "tests" / "fixtures" / "cenario-referencia.json"
    data = json.loads(fixture_path.read_text(encoding="utf-8"))
    i = data["inputs"]
    dec = Decimal
    labor = dec(i["workers"]) * dec(i["monthlyCostPerWorker"]) * 12 * dec(i["productivityLossRate"])
    base = dec(i["monthlyCoolingCost"]) * 12
    materials = dec(i["annualTemperatureSensitiveMaterialsValue"]) * dec(i["annualHeatAttributableMaterialLossRate"])
    growth = dec(i["annualCoolingConsumptionGrowthRate"])
    energy_total = dec(0)
    for row in data["expectedAnnual"]:
        year = row["year"]
        full_energy = base * (1 + growth) ** year
        additional = full_energy - base
        economic = labor + materials + additional
        assert labor == dec(row["laborEquivalent"])
        assert full_energy == dec(row["coolingTotal"])
        assert additional == dec(row["coolingIncrement"])
        assert materials == dec(row["materialLoss"])
        assert economic == dec(row["economicExposure"])
        assert money(additional) == row["displayRounded"]["coolingIncrement"]
        assert money(economic) == row["displayRounded"]["economicExposure"]
        energy_total += additional
    expected = data["expectedCumulative"]
    years = i["horizonYears"]
    total = (labor + materials) * years + energy_total
    assert labor * years == dec(expected["laborEquivalent"])
    assert materials * years == dec(expected["materialLoss"])
    assert energy_total == dec(expected["coolingIncrement"])
    assert total == dec(expected["economicExposure"])
    assert money(total) == expected["displayRounded"]["economicExposure"]

    roi = data["syntheticROITestOnly"]
    benefit = dec(roi["annualCoolingCost"]) * dec(roi["hypotheticalSavingRate"])
    investment = dec(roi["initialInvestment"])
    net = benefit * roi["horizonYears"] - investment
    assert money(benefit) == roi["expectedAnnualBenefit"]
    assert investment / benefit == dec(roi["expectedSimplePaybackYears"])
    assert money(net) == roi["expectedNetGainFiveYears"]
    assert 100 * net / investment == dec(roi["expectedSimpleROIPercent"])
    assert 100 * benefit / dec(roi["annualRevenue"]) == dec(roi["expectedMarginImprovementPercentagePoints"])
    print("PASS: annual rows, cumulative values, decimal rounding and synthetic ROI fixture.")
    print("Year 1 exposure (BRL):", data["expectedAnnual"][0]["displayRounded"]["economicExposure"])
    print("Five-year exposure (BRL):", money(total))
    print("This verifies arithmetic only; not scientific assumptions or a production application.")

if __name__ == "__main__":
    main()
