# Grupo 3TC — pacote de briefing para implementação com Codex

## O que este pacote contém

Um prompt de implementação, orientação curta para o repositório, 19 fontes candidatas e referências numéricas recalculadas. **Não é a aplicação pronta.** Os sistemas descritos no prompt são entregáveis para o agente desenvolver.

A base é o histórico visível do chat. O arquivo “Grupo_3TC_Compilacao_Parcial_Conversa.pdf”, consultado nesta preparação, é um resumo temático de três páginas, não a transcrição integral. Ele confirma as premissas finais da simulação e o posicionamento industrial. Nenhum arquivo externo foi tratado como validação científica apenas por ter sido mencionado.

## Como iniciar

Abra `PROMPT_MESTRE_3TC_CODEX.md` no ambiente em que o agente tenha acesso ao Codex e ao repositório. Forneça também os outros arquivos deste pacote. A instrução de partida pode ser:

> Leia PROMPT_MESTRE_3TC_CODEX.md, inspecione o repositório e use o Codex para implementar primeiro o escopo A e depois o escopo B proposto. Respeite os limites do briefing. Entregue arquivos funcionais, testes executados e limitações verificáveis; não entregue somente um plano.

Não substitua o AGENTS.md de um projeto existente automaticamente: reconcilie o exemplo fornecido com as instruções do repositório.

## Arquivos

- `PROMPT_MESTRE_3TC_CODEX.md`: contexto, escopo, fórmulas, módulos, interface, testes e entregáveis.
- `AGENTS.md`: proposta concisa de instruções persistentes para implementação.
- `data/fontes-candidatas.json`: 19 referências herdadas do chat, todas com verificação pendente.
- `tests/fixtures/cenario-referencia.json`: entradas finais, resultados exatos e teste sintético de ROI.
- `reference_calculation.py`: conferência independente da aritmética com a biblioteca padrão do Python.
- `VERIFICACAO_NUMERICA.txt`: resultado real da execução da conferência.
- `PROVENIENCIA.md`: origem do contexto e separação entre decisões do chat e proposta funcional.

Execute a conferência com:
```bash
python reference_calculation.py
```

## Quatro módulos propostos

Calculadora de exposição econômica; apresentação e relatórios; análise opcional de investimento; biblioteca de evidências. Um único motor deve servir a todos. Não há razão definida para quatro aplicações independentes.

## O que foi verificado neste pacote

A aritmética do cenário final, os arquivos JSON e a consistência dos resultados de referência. As fontes científicas NÃO foram auditadas aqui: URLs e números herdados foram preservados como candidatos, com limites e pendências explícitos. Não há garantia de que cada link ainda ofereça download.

A consulta externa desta preparação foi restrita à documentação oficial sobre orientação de agentes Codex, instruções de repositório e evidências de testes. Ela não valida os estudos de calor nem amplia silenciosamente o escopo empresarial.

## Cuidados de uso

O valor de produtividade é capacidade econômica equivalente, não perda de caixa comprovada. Os percentuais 3%/3%/1% são hipóteses. O total de exposição não equivale a economia recuperável por isolamento. ROI exige benefício atribuível, investimento e custos definidos.

Os recursos B são proposta de produto deste briefing; C é backlog, não trabalho realizado nem pedido histórico confirmado. Publicação em produção, integração com terceiros e uso de dados reais dependem de autorização.
